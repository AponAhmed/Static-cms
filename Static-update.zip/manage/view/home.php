<?php admin_header(); ?>
<div class="page-body">
    Home
</div>
<?php admin_footer(); ?>