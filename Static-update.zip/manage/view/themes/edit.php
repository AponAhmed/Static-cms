<?php admin_header(); ?>
<div class="page-body">
    <div class="theme-edit-container">
        Theme File Editor
    </div>
</div>
<?php admin_footer(); ?>