<?php get_header();
?>
<main role="main">
    <div class="page">
        <div class="container">
            <div class="banner-simple">
                <h1>404 Not Found !</h1>
                <p>The page you are looking for does not exist.</p>
            </div>
        </div>
    </div>
</main>
<?php get_footer(); ?>