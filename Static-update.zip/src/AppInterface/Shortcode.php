<?php

namespace Aponahmed\Cmsstatic\AppInterface;


interface Shortcode
{
    public function filter();
}
