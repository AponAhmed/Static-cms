<div class="top-bar">
    <div class="page-title">
        <?php admin_page_title() ?>
        <?php admin_page_new() ?>
    </div>
    <div class="login-bar">
        <a href="<?php echo admin_url() ?>/logout" class="logout-btn">Logout</a>
    </div>
</div>